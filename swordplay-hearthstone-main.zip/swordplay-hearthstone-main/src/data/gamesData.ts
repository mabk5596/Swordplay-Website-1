export interface Game {
  id: string;
  title: string;
  logo: string;
  tagline: string;
  description: string;
  features: string[];
  images: string[];
}

import mythicBg from "@/assets/game-mythic-bg.jpg";
import cyberBg from "@/assets/game-cyber-bg.jpg";
import shadowBg from "@/assets/game-shadow-bg.jpg";
import mythicFeature1 from "@/assets/mythic-feature-1.jpg";
import mythicFeature2 from "@/assets/mythic-feature-2.jpg";
import mythicFeature3 from "@/assets/mythic-feature-3.jpg";
import mythicFeature4 from "@/assets/mythic-feature-4.jpg";
import cyberFeature1 from "@/assets/cyber-feature-1.jpg";
import cyberFeature2 from "@/assets/cyber-feature-2.jpg";
import cyberFeature3 from "@/assets/cyber-feature-3.jpg";
import cyberFeature4 from "@/assets/cyber-feature-4.jpg";
import shadowFeature1 from "@/assets/shadow-feature-1.jpg";
import shadowFeature2 from "@/assets/shadow-feature-2.jpg";
import shadowFeature3 from "@/assets/shadow-feature-3.jpg";
import shadowFeature4 from "@/assets/shadow-feature-4.jpg";

export const games: Game[] = [
  {
    id: "mythic-legends",
    title: "Mythic Legends",
    logo: mythicBg,
    tagline: "Embark on an epic fantasy adventure",
    description: "Dive into a world of ancient magic and legendary heroes. Mythic Legends combines stunning visuals with deep RPG mechanics to create an unforgettable gaming experience.",
    features: [
      "Expansive open world with dynamic weather",
      "Deep character customization system",
      "Epic boss battles and challenging dungeons",
      "Rich storyline with multiple endings"
    ],
    images: [
      mythicFeature1,
      mythicFeature2,
      mythicFeature3,
      mythicFeature4
    ]
  },
  {
    id: "cyber-warriors",
    title: "Cyber Warriors",
    logo: cyberBg,
    tagline: "Fight for the future in a dystopian cyberpunk world",
    description: "In a neon-lit metropolis where technology and humanity collide, you must navigate through corporate conspiracies and street warfare to uncover the truth.",
    features: [
      "Fast-paced tactical combat system",
      "Cybernetic enhancement customization",
      "Branching narrative with meaningful choices",
      "Stunning cyberpunk aesthetics"
    ],
    images: [
      cyberFeature1,
      cyberFeature2,
      cyberFeature3,
      cyberFeature4
    ]
  },
  {
    id: "shadow-realm",
    title: "Shadow Realm",
    logo: shadowBg,
    tagline: "Survive the darkness, embrace your power",
    description: "A dark fantasy roguelike where every death makes you stronger. Master shadow magic and defeat nightmarish creatures in procedurally generated dungeons.",
    features: [
      "Roguelike gameplay with permanent progression",
      "Unique shadow magic system",
      "Challenging boss encounters",
      "Beautiful hand-drawn art style"
    ],
    images: [
      shadowFeature1,
      shadowFeature2,
      shadowFeature3,
      shadowFeature4
    ]
  }
];
