export interface TeamMember {
  id: string;
  name: string;
  designation: string;
  team: "art" | "dev" | "sound" | "production" | "leadership";
  image: string;
  bio?: string;
}

export const teamMembers: TeamMember[] = [
  // Leadership Team
  {
    id: "l1",
    name: "Sarah Chen",
    designation: "CEO & Co-Founder",
    team: "leadership",
    image: "/team/sarah-chen.jpg",
    bio: "Visionary leader with 15+ years in game development"
  },
  {
    id: "l2",
    name: "Marcus Rivera",
    designation: "Creative Director",
    team: "leadership",
    image: "/team/marcus-rivera.jpg",
    bio: "Award-winning game designer and storyteller"
  },
  {
    id: "l3",
    name: "Emily Watkins",
    designation: "COO",
    team: "leadership",
    image: "/team/emily-watkins.jpg",
    bio: "Operations expert ensuring smooth studio workflow"
  },

  // Dev Team
  {
    id: "d1",
    name: "Alex Kumar",
    designation: "Lead Engineer",
    team: "dev",
    image: "/team/alex-kumar.jpg",
    bio: "Expert in game engine architecture and optimization"
  },
  {
    id: "d2",
    name: "Jessica Park",
    designation: "Senior Gameplay Programmer",
    team: "dev",
    image: "/team/jessica-park.jpg",
    bio: "Specializes in creating fluid combat systems"
  },
  {
    id: "d3",
    name: "David Lopez",
    designation: "Tools Programmer",
    team: "dev",
    image: "/team/david-lopez.jpg",
    bio: "Building editor tools that empower our team"
  },

  // Art Team
  {
    id: "a1",
    name: "Zoe Thompson",
    designation: "Art Director",
    team: "art",
    image: "/team/zoe-thompson.jpg",
    bio: "Crafting breathtaking visual experiences"
  },
  {
    id: "a2",
    name: "Raj Patel",
    designation: "Lead Character Artist",
    team: "art",
    image: "/team/raj-patel.jpg",
    bio: "Bringing characters to life with stunning detail"
  },
  {
    id: "a3",
    name: "Mia Anderson",
    designation: "Environment Artist",
    team: "art",
    image: "/team/mia-anderson.jpg",
    bio: "Creating immersive worlds and atmospheric scenes"
  },

  // Sound Team
  {
    id: "s1",
    name: "Jordan Lee",
    designation: "Audio Director",
    team: "sound",
    image: "/team/jordan-lee.jpg",
    bio: "Composing epic soundtracks and immersive soundscapes"
  },
  {
    id: "s2",
    name: "Nina Schmidt",
    designation: "Sound Designer",
    team: "sound",
    image: "/team/nina-schmidt.jpg",
    bio: "Crafting every sound effect with precision"
  },

  // Production Team
  {
    id: "p1",
    name: "Chris Martin",
    designation: "Producer",
    team: "production",
    image: "/team/chris-martin.jpg",
    bio: "Keeping projects on track and teams aligned"
  },
  {
    id: "p2",
    name: "Aisha Khan",
    designation: "QA Lead",
    team: "production",
    image: "/team/aisha-khan.jpg",
    bio: "Ensuring quality and polish in every release"
  }
];
